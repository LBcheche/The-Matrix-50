
function love.conf(t)
    t.window.borderless = true
    t.window.fullscreen = true 
    t.window.resizable = true
end